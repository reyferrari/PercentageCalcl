function calculatePercentage(type) {
    const resultElement = document.getElementById('result');
    resultElement.innerHTML = '';

    switch (type) {
        case 'of':
            calculatePercentageOf();
            break;
        case 'change':
            calculatePercentageChange();
            break;
        case 'difference':
            calculatePercentageDifference();
            break;
        default:
            break;
    }
}

function calculatePercentageOf() {
    const originalValue = parseFloat(document.getElementById('originalValue').value);
    const percentage = parseFloat(document.getElementById('percentage').value);

    if (!isNaN(originalValue) && !isNaN(percentage)) {
        const result = (percentage / 100) * originalValue;
        displayResult(result);
    }
}

function calculatePercentageChange() {
    const startValue = parseFloat(document.getElementById('startValue').value);
    const endValue = parseFloat(document.getElementById('endValue').value);

    if (!isNaN(startValue) && !isNaN(endValue)) {
        const change = endValue - startValue;
        const percentageChange = (change / Math.abs(startValue)) * 100;
        displayResult(percentageChange);
    }
}

function calculatePercentageDifference() {
    const firstNumber = parseFloat(document.getElementById('firstNumber').value);
    const secondNumber = parseFloat(document.getElementById('secondNumber').value);

    if (!isNaN(firstNumber) && !isNaN(secondNumber) && firstNumber !== 0) {
        const difference = ((secondNumber - firstNumber) / Math.abs(firstNumber)) * 100;
        displayResult(difference);
    }
}

function displayResult(result) {
    const resultElement = document.getElementById('result');
    resultElement.innerHTML = `Result: ${result.toFixed(2)}%`;
}